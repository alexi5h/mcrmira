﻿# Host: localhost  (Version: 5.6.17)
# Date: 2014-07-29 21:07:09
# Generator: MySQL-Front 5.3  (Build 4.133)

/*!40101 SET NAMES utf8 */;

#
# Data for table "barrio"
#


#
# Data for table "canton"
#


#
# Data for table "credito"
#


#
# Data for table "cruge_authassignment"
#


#
# Data for table "cruge_authitem"
#


#
# Data for table "cruge_authitemchild"
#


#
# Data for table "cruge_field"
#


#
# Data for table "cruge_fieldvalue"
#


#
# Data for table "cruge_session"
#


#
# Data for table "cruge_system"
#

INSERT INTO `cruge_system` (`idsystem`,`name`,`largename`,`sessionmaxdurationmins`,`sessionmaxsameipconnections`,`sessionreusesessions`,`sessionmaxsessionsperday`,`sessionmaxsessionsperuser`,`systemnonewsessions`,`systemdown`,`registerusingcaptcha`,`registerusingterms`,`terms`,`registerusingactivation`,`defaultroleforregistration`,`registerusingtermslabel`,`registrationonlogin`) VALUES (1,'default',NULL,800,10,1,-1,-1,0,0,0,0,NULL,0,'','',1);

#
# Data for table "cruge_user"
#

INSERT INTO `cruge_user` (`iduser`,`regdate`,`actdate`,`logondate`,`username`,`email`,`password`,`authkey`,`state`,`totalsessioncounter`,`currentsessioncounter`) VALUES (1,NULL,NULL,1406685837,'admin','armand1live@gmail.com','admin','admin',1,0,0);

#
# Data for table "deposito"
#


#
# Data for table "direccion"
#


#
# Data for table "entidad_bacaria"
#


#
# Data for table "pago_mes"
#


#
# Data for table "parroquia"
#


#
# Data for table "persona"
#


#
# Data for table "persona_etapa"
#


#
# Data for table "provincia"
#


#
# Data for table "sucursal"
#

